<?php

namespace React\Filesystem;

use Exception;

class NotSupportedException extends Exception
{

}

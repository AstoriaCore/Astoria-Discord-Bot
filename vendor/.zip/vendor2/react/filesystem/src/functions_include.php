<?php

namespace React\Filesystem;

if (!function_exists('React\Filesystem\getInvoker')) {
    require __DIR__ . '/functions.php';
}

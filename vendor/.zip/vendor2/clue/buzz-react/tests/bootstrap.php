<?php

use PHPUnit\Framework\TestCase as BaseTestCase;

require __DIR__ . '/../vendor/autoload.php';

error_reporting(-1);

class TestCase extends BaseTestCase
{
}

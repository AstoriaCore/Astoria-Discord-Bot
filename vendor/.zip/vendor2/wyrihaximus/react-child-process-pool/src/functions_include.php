<?php

namespace WyriHaximus\React\ChildProcess\Pool;

// @codeCoverageIgnoreStart
if (!function_exists('WyriHaximus\React\ChildProcess\Pool\getClassNameFromOptionOrDefault')) {
    require __DIR__ . '/functions.php';
}
// @codeCoverageIgnoreEnd

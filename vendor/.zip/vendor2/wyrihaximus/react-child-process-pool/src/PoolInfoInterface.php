<?php

namespace WyriHaximus\React\ChildProcess\Pool;

interface PoolInfoInterface
{
    /**
     * @return array
     */
    public function info();
}

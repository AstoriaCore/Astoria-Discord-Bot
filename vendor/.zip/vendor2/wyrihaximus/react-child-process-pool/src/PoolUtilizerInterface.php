<?php

namespace WyriHaximus\React\ChildProcess\Pool;

interface PoolUtilizerInterface extends PoolInfoInterface
{
}

<?php

namespace WyriHaximus\CpuCoreDetector\Core;

use WyriHaximus\CpuCoreDetector\CoreInterface;

interface AffinityInterface extends CoreInterface
{

}

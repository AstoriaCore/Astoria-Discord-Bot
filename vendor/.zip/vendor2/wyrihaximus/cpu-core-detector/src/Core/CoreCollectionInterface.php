<?php

namespace WyriHaximus\CpuCoreDetector\Core;

use Iterator;

interface CoreCollectionInterface extends Iterator
{

}

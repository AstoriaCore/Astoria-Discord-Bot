<?php

namespace WyriHaximus\CpuCoreDetector;

if (!function_exists('WyriHaximus\CpuCoreDetector\getDefaultCollections(')) {
    require __DIR__ . '/functions.php';
}

<?php

namespace WyriHaximus\React;

// @codeCoverageIgnoreStart
if (!function_exists('WyriHaximus\React\futurePromise')) {
    require __DIR__ . '/functions.php';
}
// @codeCoverageIgnoreEnd

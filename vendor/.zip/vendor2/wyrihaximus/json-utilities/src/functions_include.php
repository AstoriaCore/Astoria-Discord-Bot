<?php declare(strict_types=1);

namespace WyriHaximus\React;

if (!\function_exists('WyriHaximus\validate_array')) {
    require __DIR__ . '/functions.php';
}

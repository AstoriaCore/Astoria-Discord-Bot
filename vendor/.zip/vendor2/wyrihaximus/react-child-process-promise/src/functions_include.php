<?php

namespace WyriHaximus\React;

if (!function_exists('WyriHaximus\React\childProcessPromise')) {
    require __DIR__ . '/functions.php';
}

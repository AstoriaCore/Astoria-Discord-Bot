<?php

namespace WyriHaximus\React;

if (!function_exists('WyriHaximus\throwable_encode')) {
    require __DIR__ . '/functions.php';
}
